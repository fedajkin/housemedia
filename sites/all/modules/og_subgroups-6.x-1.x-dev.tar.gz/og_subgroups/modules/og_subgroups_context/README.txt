
Context for OG Subgroups using Context 3.x for Drupal 6.x
---------------------------------------------------------

Installation
------------
1. Context can be installed like any other Drupal module -- place it in
the modules directory for your site and enable it.

2. Currently you must clear all caches (the button on the
admin/settings/performance screen is one way to do it) in order to
see the new conditions and reactions that are provided by this module.

